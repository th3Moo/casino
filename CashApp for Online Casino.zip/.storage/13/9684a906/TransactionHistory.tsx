import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Search,
  Download,
  Calendar,
  Filter,
  CheckCircle,
  XCircle,
  Clock,
  DollarSign,
  TrendingUp,
  ArrowLeft
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface UserTransaction {
  id: string;
  type: 'deposit' | 'withdrawal';
  amount: number;
  cashAppTag: string;
  status: 'pending' | 'completed' | 'failed';
  timestamp: Date;
  fee: number;
  confirmationNumber?: string;
}

export default function TransactionHistory() {
  const navigate = useNavigate();
  const [transactions, setTransactions] = useState<UserTransaction[]>([]);
  const [filteredTransactions, setFilteredTransactions] = useState<UserTransaction[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [dateRange, setDateRange] = useState<string>('all');

  // Generate mock transaction history
  useEffect(() => {
    const mockTransactions: UserTransaction[] = [
      {
        id: 'dep_001',
        type: 'deposit',
        amount: 100,
        cashAppTag: '$myusername',
        status: 'completed',
        timestamp: new Date(Date.now() - 1000 * 60 * 30),
        fee: 0,
        confirmationNumber: 'CA123456789'
      },
      {
        id: 'with_001',
        type: 'withdrawal',
        amount: 75,
        cashAppTag: '$myusername',
        status: 'completed',
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2),
        fee: 0,
        confirmationNumber: 'CA987654321'
      },
      {
        id: 'dep_002',
        type: 'deposit',
        amount: 250,
        cashAppTag: '$myusername',
        status: 'pending',
        timestamp: new Date(Date.now() - 1000 * 60 * 10),
        fee: 0
      },
      {
        id: 'with_002',
        type: 'withdrawal',
        amount: 150,
        cashAppTag: '$myusername',
        status: 'failed',
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24),
        fee: 0
      },
      {
        id: 'dep_003',
        type: 'deposit',
        amount: 50,
        cashAppTag: '$myusername',
        status: 'completed',
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2),
        fee: 0,
        confirmationNumber: 'CA456789123'
      },
      {
        id: 'with_003',
        type: 'withdrawal',
        amount: 200,
        cashAppTag: '$myusername',
        status: 'completed',
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3),
        fee: 0,
        confirmationNumber: 'CA654321987'
      }
    ];
    setTransactions(mockTransactions);
    setFilteredTransactions(mockTransactions);
  }, []);

  // Filter transactions
  useEffect(() => {
    let filtered = transactions;

    if (searchTerm) {
      filtered = filtered.filter(txn => 
        txn.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        txn.confirmationNumber?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (statusFilter !== 'all') {
      filtered = filtered.filter(txn => txn.status === statusFilter);
    }

    if (typeFilter !== 'all') {
      filtered = filtered.filter(txn => txn.type === typeFilter);
    }

    if (dateRange !== 'all') {
      const now = new Date();
      const filterDate = new Date();
      
      switch (dateRange) {
        case '24h':
          filterDate.setHours(now.getHours() - 24);
          break;
        case '7d':
          filterDate.setDate(now.getDate() - 7);
          break;
        case '30d':
          filterDate.setDate(now.getDate() - 30);
          break;
      }
      
      if (dateRange !== 'all') {
        filtered = filtered.filter(txn => txn.timestamp >= filterDate);
      }
    }

    setFilteredTransactions(filtered);
  }, [transactions, searchTerm, statusFilter, typeFilter, dateRange]);

  const getStatusBadge = (status: string) => {
    const colors = {
      completed: 'bg-green-100 text-green-800',
      pending: 'bg-yellow-100 text-yellow-800',
      failed: 'bg-red-100 text-red-800'
    };
    return colors[status as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'failed':
        return <XCircle className="h-4 w-4 text-red-500" />;
      default:
        return <Clock className="h-4 w-4 text-yellow-500" />;
    }
  };

  const getTotalDeposits = () => {
    return transactions
      .filter(t => t.type === 'deposit' && t.status === 'completed')
      .reduce((sum, t) => sum + t.amount, 0);
  };

  const getTotalWithdrawals = () => {
    return transactions
      .filter(t => t.type === 'withdrawal' && t.status === 'completed')
      .reduce((sum, t) => sum + t.amount, 0);
  };

  const getNetBalance = () => {
    return getTotalDeposits() - getTotalWithdrawals();
  };

  const exportTransactions = () => {
    const csvContent = [
      ['Transaction ID', 'Type', 'Amount', 'Status', 'Date', 'Confirmation Number'],
      ...filteredTransactions.map(txn => [
        txn.id,
        txn.type,
        txn.amount.toString(),
        txn.status,
        txn.timestamp.toLocaleDateString(),
        txn.confirmationNumber || 'N/A'
      ])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'transaction-history.csv';
    a.click();
    window.URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate('/')}
              className="text-white hover:bg-white/10"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
            <div>
              <h1 className="text-4xl font-bold text-white mb-2">Transaction History</h1>
              <p className="text-slate-300">View and manage your payment history</p>
            </div>
          </div>
          <Button onClick={exportTransactions} className="bg-green-600 hover:bg-green-700">
            <Download className="h-4 w-4 mr-2" />
            Export CSV
          </Button>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-white/95 backdrop-blur">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Deposits</CardTitle>
              <DollarSign className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">${getTotalDeposits()}</div>
              <p className="text-xs text-muted-foreground">
                {transactions.filter(t => t.type === 'deposit' && t.status === 'completed').length} completed deposits
              </p>
            </CardContent>
          </Card>

          <Card className="bg-white/95 backdrop-blur">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Withdrawals</CardTitle>
              <TrendingUp className="h-4 w-4 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">${getTotalWithdrawals()}</div>
              <p className="text-xs text-muted-foreground">
                {transactions.filter(t => t.type === 'withdrawal' && t.status === 'completed').length} completed withdrawals
              </p>
            </CardContent>
          </Card>

          <Card className="bg-white/95 backdrop-blur">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Net Balance</CardTitle>
              <DollarSign className="h-4 w-4 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${getNetBalance() >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                ${getNetBalance()}
              </div>
              <p className="text-xs text-muted-foreground">
                Deposits minus withdrawals
              </p>
            </CardContent>
          </Card>
        </div>

        <Card className="bg-white/95 backdrop-blur">
          <CardHeader>
            <CardTitle>Transaction History</CardTitle>
            <CardDescription>Complete record of your CashApp transactions</CardDescription>
          </CardHeader>
          <CardContent>
            {/* Filters */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search transactions..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="failed">Failed</SelectItem>
                </SelectContent>
              </Select>

              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Filter by type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="deposit">Deposits</SelectItem>
                  <SelectItem value="withdrawal">Withdrawals</SelectItem>
                </SelectContent>
              </Select>

              <Select value={dateRange} onValueChange={setDateRange}>
                <SelectTrigger>
                  <SelectValue placeholder="Date range" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Time</SelectItem>
                  <SelectItem value="24h">Last 24 Hours</SelectItem>
                  <SelectItem value="7d">Last 7 Days</SelectItem>
                  <SelectItem value="30d">Last 30 Days</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Transactions Table */}
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Transaction ID</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Confirmation</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredTransactions.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                        No transactions found
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredTransactions.map((transaction) => (
                      <TableRow key={transaction.id}>
                        <TableCell className="font-mono text-sm">{transaction.id}</TableCell>
                        <TableCell>
                          <Badge variant={transaction.type === 'deposit' ? 'default' : 'secondary'}>
                            {transaction.type}
                          </Badge>
                        </TableCell>
                        <TableCell className="font-mono">
                          <span className={transaction.type === 'deposit' ? 'text-green-600' : 'text-blue-600'}>
                            {transaction.type === 'deposit' ? '+' : '-'}${transaction.amount}
                          </span>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {getStatusIcon(transaction.status)}
                            <Badge className={getStatusBadge(transaction.status)}>
                              {transaction.status}
                            </Badge>
                          </div>
                        </TableCell>
                        <TableCell className="text-sm">
                          {transaction.timestamp.toLocaleString()}
                        </TableCell>
                        <TableCell className="font-mono text-sm">
                          {transaction.confirmationNumber || 'Pending'}
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>

            {/* Pagination would go here for larger datasets */}
            {filteredTransactions.length > 0 && (
              <div className="mt-4 text-sm text-muted-foreground text-center">
                Showing {filteredTransactions.length} of {transactions.length} transactions
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}