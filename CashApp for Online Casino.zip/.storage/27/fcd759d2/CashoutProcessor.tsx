import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { DollarSign, AlertCircle, CheckCircle2, Clock, Copy } from 'lucide-react';
import { toast } from 'sonner';

interface CashoutRequest {
  id: string;
  playerTag: string;
  amount: number;
  currency: 'USDT' | 'USD';
  walletAddress?: string;
  cashAppTag?: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  timestamp: Date;
  adminNotes?: string;
}

interface CashoutProcessorProps {
  playerBalance: number;
  playerTag: string;
  onCashoutRequest: (amount: number, currency: 'USDT' | 'USD', details: any) => void;
}

export default function CashoutProcessor({ playerBalance, playerTag, onCashoutRequest }: CashoutProcessorProps) {
  const [amount, setAmount] = useState('');
  const [currency, setCurrency] = useState<'USDT' | 'USD'>('USD');
  const [walletAddress, setWalletAddress] = useState('');
  const [cashAppTag, setCashAppTag] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [cashoutRequests, setCashoutRequests] = useState<CashoutRequest[]>([]);

  const MINIMUM_CASHOUT = 1000;

  const handleCashout = async () => {
    const cashoutAmount = parseFloat(amount);

    // Validation
    if (!amount || cashoutAmount <= 0) {
      toast.error('Please enter a valid amount');
      return;
    }

    if (cashoutAmount < MINIMUM_CASHOUT) {
      toast.error(`Minimum cashout amount is $${MINIMUM_CASHOUT}`);
      return;
    }

    if (cashoutAmount > playerBalance) {
      toast.error('Insufficient balance for this cashout');
      return;
    }

    if (currency === 'USDT' && !walletAddress) {
      toast.error('Please enter your USDT wallet address');
      return;
    }

    if (currency === 'USD' && !cashAppTag) {
      toast.error('Please enter your CashApp tag for USD cashout');
      return;
    }

    setIsProcessing(true);

    // Create cashout request
    const request: CashoutRequest = {
      id: `cashout_${Date.now()}`,
      playerTag,
      amount: cashoutAmount,
      currency,
      walletAddress: currency === 'USDT' ? walletAddress : undefined,
      cashAppTag: currency === 'USD' ? cashAppTag : undefined,
      status: 'pending',
      timestamp: new Date()
    };

    setCashoutRequests(prev => [request, ...prev]);
    onCashoutRequest(cashoutAmount, currency, {
      walletAddress: currency === 'USDT' ? walletAddress : undefined,
      cashAppTag: currency === 'USD' ? cashAppTag : undefined
    });

    // Reset form
    setAmount('');
    setWalletAddress('');
    setCashAppTag('');
    setIsProcessing(false);

    toast.success(`Cashout request of $${cashoutAmount} ${currency} submitted for review`);

    // Simulate processing (in real implementation, this would be handled by admin)
    setTimeout(() => {
      setCashoutRequests(prev => 
        prev.map(req => 
          req.id === request.id 
            ? { ...req, status: 'processing' as const, adminNotes: 'Under review by admin' }
            : req
        )
      );
      toast.info('Cashout request is now under admin review');
    }, 3000);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle2 className="h-4 w-4 text-green-500" />;
      case 'failed':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
      case 'processing':
        return <Clock className="h-4 w-4 text-blue-500" />;
      default:
        return <Clock className="h-4 w-4 text-yellow-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'failed':
        return 'bg-red-100 text-red-800';
      case 'processing':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-yellow-100 text-yellow-800';
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Copied to clipboard');
  };

  return (
    <div className="space-y-6">
      <Card className="bg-white/95 backdrop-blur">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="h-5 w-5 text-green-500" />
            Cashout Request
          </CardTitle>
          <CardDescription>
            Request withdrawal to USDT wallet or USD via CashApp
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert className="border-blue-200 bg-blue-50">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription className="text-blue-800">
              <strong>Current Balance:</strong> ${playerBalance.toFixed(2)} • <strong>Minimum Cashout:</strong> ${MINIMUM_CASHOUT}
            </AlertDescription>
          </Alert>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="cashout-amount">Cashout Amount</Label>
              <div className="relative">
                <DollarSign className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="cashout-amount"
                  type="number"
                  placeholder={`Min ${MINIMUM_CASHOUT}`}
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="pl-10"
                  min={MINIMUM_CASHOUT}
                  max={playerBalance}
                />
              </div>
            </div>
            
            <div>
              <Label htmlFor="currency">Currency</Label>
              <Select value={currency} onValueChange={(value: 'USDT' | 'USD') => setCurrency(value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select currency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="USD">USD (CashApp)</SelectItem>
                  <SelectItem value="USDT">USDT (Crypto Wallet)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {currency === 'USDT' && (
            <div>
              <Label htmlFor="wallet-address">USDT Wallet Address (TRC20/ERC20)</Label>
              <Input
                id="wallet-address"
                placeholder="Enter your USDT wallet address"
                value={walletAddress}
                onChange={(e) => setWalletAddress(e.target.value)}
              />
              <p className="text-xs text-muted-foreground mt-1">
                Supports TRC20 (Tron) and ERC20 (Ethereum) USDT addresses
              </p>
            </div>
          )}

          {currency === 'USD' && (
            <div>
              <Label htmlFor="cashapp-tag">CashApp Tag</Label>
              <Input
                id="cashapp-tag"
                placeholder="$YourCashAppTag"
                value={cashAppTag}
                onChange={(e) => setCashAppTag(e.target.value)}
              />
              <p className="text-xs text-muted-foreground mt-1">
                USD will be sent directly to your CashApp account
              </p>
            </div>
          )}

          <Button 
            onClick={handleCashout}
            disabled={isProcessing || playerBalance < MINIMUM_CASHOUT}
            className="w-full bg-green-600 hover:bg-green-700"
          >
            {isProcessing ? 'Processing...' : `Request ${currency} Cashout`}
          </Button>

          {playerBalance < MINIMUM_CASHOUT && (
            <Alert className="border-orange-200 bg-orange-50">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription className="text-orange-800">
                You need at least ${MINIMUM_CASHOUT - playerBalance} more to reach the minimum cashout amount.
              </AlertDescription>
            </Alert>
          )}

          <div className="text-sm text-muted-foreground space-y-1">
            <p>• Minimum cashout: ${MINIMUM_CASHOUT}</p>
            <p>• Processing time: 24-48 hours</p>
            <p>• USDT: No fees (gas fees may apply)</p>
            <p>• USD: 2% processing fee</p>
          </div>
        </CardContent>
      </Card>

      {/* Cashout History */}
      {cashoutRequests.length > 0 && (
        <Card className="bg-white/95 backdrop-blur">
          <CardHeader>
            <CardTitle>Cashout History</CardTitle>
            <CardDescription>Your recent cashout requests</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {cashoutRequests.slice(0, 5).map((request) => (
                <div key={request.id} className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      {getStatusIcon(request.status)}
                      <div>
                        <p className="font-medium">
                          ${request.amount} {request.currency}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {request.timestamp.toLocaleString()}
                        </p>
                      </div>
                    </div>
                    <Badge className={getStatusColor(request.status)}>
                      {request.status}
                    </Badge>
                  </div>

                  <div className="space-y-2 text-sm">
                    {request.currency === 'USDT' && request.walletAddress && (
                      <div className="flex items-center gap-2">
                        <span className="text-muted-foreground">Wallet:</span>
                        <code className="bg-gray-100 px-2 py-1 rounded text-xs flex-1">
                          {request.walletAddress}
                        </code>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => copyToClipboard(request.walletAddress!)}
                        >
                          <Copy className="h-3 w-3" />
                        </Button>
                      </div>
                    )}
                    
                    {request.currency === 'USD' && request.cashAppTag && (
                      <div className="flex items-center gap-2">
                        <span className="text-muted-foreground">CashApp:</span>
                        <span className="font-mono">{request.cashAppTag}</span>
                      </div>
                    )}

                    {request.adminNotes && (
                      <div className="text-muted-foreground">
                        <strong>Note:</strong> {request.adminNotes}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}