import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Gamepad2, 
  Users, 
  DollarSign, 
  Trophy, 
  Settings,
  ArrowLeft,
  Play,
  Pause,
  RotateCcw
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import CashAppProcessor from '@/components/CashAppProcessor';

interface Player {
  id: string;
  cashTag: string;
  balance: number;
  status: 'active' | 'inactive';
  joinedAt: Date;
}

interface GameSession {
  id: string;
  status: 'waiting' | 'active' | 'finished';
  players: Player[];
  pot: number;
  winner?: string;
}

export default function PayFateGameroom() {
  const navigate = useNavigate();
  const [gameSession, setGameSession] = useState<GameSession>({
    id: 'session_001',
    status: 'waiting',
    players: [],
    pot: 0
  });
  const [houseCashTag] = useState('PayFateHouse'); // Your CashApp username here

  const handlePaymentReceived = (amount: number, playerTag: string) => {
    // Add player to game or increase their balance
    setGameSession(prev => {
      const existingPlayer = prev.players.find(p => p.cashTag === playerTag);
      
      if (existingPlayer) {
        // Increase existing player balance
        return {
          ...prev,
          players: prev.players.map(p => 
            p.cashTag === playerTag 
              ? { ...p, balance: p.balance + amount }
              : p
          ),
          pot: prev.pot + amount
        };
      } else {
        // Add new player
        const newPlayer: Player = {
          id: `player_${Date.now()}`,
          cashTag: playerTag,
          balance: amount,
          status: 'active',
          joinedAt: new Date()
        };
        return {
          ...prev,
          players: [...prev.players, newPlayer],
          pot: prev.pot + amount
        };
      }
    });
  };

  const startGame = () => {
    if (gameSession.players.length < 2) {
      alert('Need at least 2 players to start');
      return;
    }
    setGameSession(prev => ({ ...prev, status: 'active' }));
  };

  const endGame = (winnerId?: string) => {
    setGameSession(prev => ({ 
      ...prev, 
      status: 'finished',
      winner: winnerId 
    }));
  };

  const resetGame = () => {
    setGameSession({
      id: `session_${Date.now()}`,
      status: 'waiting',
      players: [],
      pot: 0
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'waiting':
        return 'bg-yellow-100 text-yellow-800';
      case 'finished':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate('/')}
              className="text-white hover:bg-white/10"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
            <div>
              <h1 className="text-4xl font-bold text-white mb-2 flex items-center gap-3">
                <Gamepad2 className="h-10 w-10 text-purple-400" />
                PayFate Gameroom
              </h1>
              <p className="text-slate-300">CashApp-powered gaming with instant deposits</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <Badge className={getStatusColor(gameSession.status)} variant="secondary">
              Game: {gameSession.status}
            </Badge>
            <Badge className="bg-green-100 text-green-800" variant="secondary">
              Pot: ${gameSession.pot}
            </Badge>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Game Control Panel */}
          <div className="lg:col-span-2">
            <Tabs defaultValue="game" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="game">Game Control</TabsTrigger>
                <TabsTrigger value="payments">Payment Processor</TabsTrigger>
                <TabsTrigger value="settings">Settings</TabsTrigger>
              </TabsList>
              
              <TabsContent value="game" className="space-y-4">
                <Card className="bg-white/95 backdrop-blur">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Play className="h-5 w-5" />
                      Game Session Control
                    </CardTitle>
                    <CardDescription>
                      Manage the current game session and players
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Game Controls */}
                    <div className="flex gap-4">
                      {gameSession.status === 'waiting' && (
                        <Button 
                          onClick={startGame}
                          disabled={gameSession.players.length < 2}
                          className="bg-green-600 hover:bg-green-700"
                        >
                          <Play className="h-4 w-4 mr-2" />
                          Start Game
                        </Button>
                      )}
                      
                      {gameSession.status === 'active' && (
                        <Button 
                          onClick={() => endGame()}
                          className="bg-red-600 hover:bg-red-700"
                        >
                          <Pause className="h-4 w-4 mr-2" />
                          End Game
                        </Button>
                      )}
                      
                      <Button 
                        onClick={resetGame}
                        variant="outline"
                      >
                        <RotateCcw className="h-4 w-4 mr-2" />
                        Reset
                      </Button>
                    </div>

                    {/* Game Board Placeholder */}
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                      <Gamepad2 className="h-16 w-16 mx-auto text-gray-400 mb-4" />
                      <h3 className="text-lg font-semibold text-gray-600 mb-2">Game Board</h3>
                      <p className="text-gray-500">
                        {gameSession.status === 'waiting' 
                          ? 'Waiting for players to join...' 
                          : gameSession.status === 'active'
                          ? 'Game in progress!'
                          : 'Game finished'}
                      </p>
                      {gameSession.status === 'finished' && gameSession.winner && (
                        <div className="mt-4">
                          <Trophy className="h-8 w-8 mx-auto text-yellow-500 mb-2" />
                          <p className="font-semibold text-green-600">
                            Winner: {gameSession.winner}
                          </p>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="payments">
                <CashAppProcessor 
                  houseCashTag={houseCashTag}
                  onPaymentReceived={handlePaymentReceived}
                />
              </TabsContent>
              
              <TabsContent value="settings">
                <Card className="bg-white/95 backdrop-blur">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Settings className="h-5 w-5" />
                      Gameroom Settings
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <label className="text-sm font-medium">House CashApp Tag</label>
                      <div className="mt-1 p-2 bg-gray-100 rounded border">
                        ${houseCashTag}
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">
                        Players send money to this CashApp tag
                      </p>
                    </div>
                    
                    <div>
                      <label className="text-sm font-medium">Minimum Buy-in</label>
                      <div className="mt-1 p-2 bg-gray-100 rounded border">
                        $5.00
                      </div>
                    </div>
                    
                    <div>
                      <label className="text-sm font-medium">Game Rules</label>
                      <textarea 
                        className="mt-1 w-full p-2 border rounded"
                        rows={3}
                        placeholder="Enter game rules here..."
                      />
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          {/* Players Panel */}
          <div>
            <Card className="bg-white/95 backdrop-blur">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Players ({gameSession.players.length})
                </CardTitle>
                <CardDescription>Active players in the gameroom</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {gameSession.players.length === 0 ? (
                    <p className="text-sm text-muted-foreground text-center py-8">
                      No players yet. Generate payment requests to add players.
                    </p>
                  ) : (
                    gameSession.players.map((player) => (
                      <div key={player.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div>
                          <p className="font-medium">{player.cashTag}</p>
                          <p className="text-sm text-muted-foreground">
                            Balance: ${player.balance}
                          </p>
                        </div>
                        <Badge 
                          className={player.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}
                        >
                          {player.status}
                        </Badge>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Game Stats */}
            <Card className="bg-white/95 backdrop-blur mt-4">
              <CardHeader>
                <CardTitle>Session Stats</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Total Pot</span>
                    <span className="text-sm font-medium">${gameSession.pot}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Active Players</span>
                    <span className="text-sm font-medium">{gameSession.players.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Game Status</span>
                    <Badge className={getStatusColor(gameSession.status)} variant="secondary">
                      {gameSession.status}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}