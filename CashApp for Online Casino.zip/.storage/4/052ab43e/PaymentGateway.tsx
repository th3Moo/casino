import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { DollarSign, CreditCard, Shield, CheckCircle, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';

interface Transaction {
  id: string;
  type: 'deposit' | 'withdrawal';
  amount: number;
  cashAppTag: string;
  status: 'pending' | 'completed' | 'failed';
  timestamp: Date;
}

export default function PaymentGateway() {
  const [depositAmount, setDepositAmount] = useState('');
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [cashAppTag, setCashAppTag] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [transactions, setTransactions] = useState<Transaction[]>([]);

  const handleDeposit = async () => {
    if (!depositAmount || !cashAppTag) {
      toast.error('Please fill in all required fields');
      return;
    }

    if (parseFloat(depositAmount) < 10) {
      toast.error('Minimum deposit amount is $10');
      return;
    }

    setIsProcessing(true);
    
    // Simulate CashApp API call
    setTimeout(() => {
      const newTransaction: Transaction = {
        id: `dep_${Date.now()}`,
        type: 'deposit',
        amount: parseFloat(depositAmount),
        cashAppTag,
        status: 'pending',
        timestamp: new Date()
      };

      setTransactions(prev => [newTransaction, ...prev]);
      toast.success('Deposit initiated! Please check your CashApp for payment request.');
      setDepositAmount('');
      setCashAppTag('');
      setIsProcessing(false);

      // Simulate status update after 3 seconds
      setTimeout(() => {
        setTransactions(prev => 
          prev.map(t => 
            t.id === newTransaction.id 
              ? { ...t, status: 'completed' as const }
              : t
          )
        );
        toast.success('Deposit completed successfully!');
      }, 3000);
    }, 2000);
  };

  const handleWithdrawal = async () => {
    if (!withdrawAmount || !cashAppTag) {
      toast.error('Please fill in all required fields');
      return;
    }

    if (parseFloat(withdrawAmount) < 20) {
      toast.error('Minimum withdrawal amount is $20');
      return;
    }

    setIsProcessing(true);

    // Simulate withdrawal processing
    setTimeout(() => {
      const newTransaction: Transaction = {
        id: `with_${Date.now()}`,
        type: 'withdrawal',
        amount: parseFloat(withdrawAmount),
        cashAppTag,
        status: 'pending',
        timestamp: new Date()
      };

      setTransactions(prev => [newTransaction, ...prev]);
      toast.success('Withdrawal request submitted! Processing typically takes 5-10 minutes.');
      setWithdrawAmount('');
      setCashAppTag('');
      setIsProcessing(false);

      // Simulate status update after 5 seconds
      setTimeout(() => {
        setTransactions(prev => 
          prev.map(t => 
            t.id === newTransaction.id 
              ? { ...t, status: 'completed' as const }
              : t
          )
        );
        toast.success('Withdrawal completed! Check your CashApp balance.');
      }, 5000);
    }, 2000);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'failed':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
      default:
        return <AlertCircle className="h-4 w-4 text-yellow-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'failed':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-yellow-100 text-yellow-800';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">BitBetWin Payment Gateway</h1>
          <p className="text-slate-300">Secure CashApp transactions for your gaming experience</p>
        </div>

        {/* Security Banner */}
        <Alert className="mb-6 border-green-500 bg-green-50">
          <Shield className="h-4 w-4" />
          <AlertDescription className="text-green-800">
            <strong>Secure & Instant:</strong> All transactions are processed through CashApp's secure payment network with end-to-end encryption.
          </AlertDescription>
        </Alert>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Payment Forms */}
          <div className="lg:col-span-2">
            <Card className="bg-white/95 backdrop-blur">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CreditCard className="h-5 w-5" />
                  CashApp Payment Processor
                </CardTitle>
                <CardDescription>
                  Make instant deposits and withdrawals using your CashApp account
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="deposit" className="w-full">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="deposit">Deposit Funds</TabsTrigger>
                    <TabsTrigger value="withdraw">Withdraw Funds</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="deposit" className="space-y-4">
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="deposit-amount">Deposit Amount (USD)</Label>
                        <div className="relative">
                          <DollarSign className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                          <Input
                            id="deposit-amount"
                            type="number"
                            placeholder="Enter amount (min $10)"
                            value={depositAmount}
                            onChange={(e) => setDepositAmount(e.target.value)}
                            className="pl-10"
                            min="10"
                          />
                        </div>
                      </div>
                      
                      <div>
                        <Label htmlFor="cashapp-tag">Your CashApp Tag</Label>
                        <Input
                          id="cashapp-tag"
                          placeholder="$YourCashAppTag"
                          value={cashAppTag}
                          onChange={(e) => setCashAppTag(e.target.value)}
                        />
                      </div>

                      <Button 
                        onClick={handleDeposit} 
                        disabled={isProcessing}
                        className="w-full bg-green-600 hover:bg-green-700"
                      >
                        {isProcessing ? 'Processing...' : 'Initiate Deposit'}
                      </Button>

                      <div className="text-sm text-muted-foreground">
                        <p>• Minimum deposit: $10</p>
                        <p>• Processing time: Instant</p>
                        <p>• Fee: Free</p>
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="withdraw" className="space-y-4">
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="withdraw-amount">Withdrawal Amount (USD)</Label>
                        <div className="relative">
                          <DollarSign className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                          <Input
                            id="withdraw-amount"
                            type="number"
                            placeholder="Enter amount (min $20)"
                            value={withdrawAmount}
                            onChange={(e) => setWithdrawAmount(e.target.value)}
                            className="pl-10"
                            min="20"
                          />
                        </div>
                      </div>
                      
                      <div>
                        <Label htmlFor="cashapp-tag-withdraw">Your CashApp Tag</Label>
                        <Input
                          id="cashapp-tag-withdraw"
                          placeholder="$YourCashAppTag"
                          value={cashAppTag}
                          onChange={(e) => setCashAppTag(e.target.value)}
                        />
                      </div>

                      <Button 
                        onClick={handleWithdrawal} 
                        disabled={isProcessing}
                        className="w-full bg-blue-600 hover:bg-blue-700"
                      >
                        {isProcessing ? 'Processing...' : 'Request Withdrawal'}
                      </Button>

                      <div className="text-sm text-muted-foreground">
                        <p>• Minimum withdrawal: $20</p>
                        <p>• Processing time: 5-10 minutes</p>
                        <p>• Fee: Free</p>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>

          {/* Transaction History */}
          <div>
            <Card className="bg-white/95 backdrop-blur">
              <CardHeader>
                <CardTitle>Recent Transactions</CardTitle>
                <CardDescription>Your latest payment activity</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {transactions.length === 0 ? (
                    <p className="text-sm text-muted-foreground text-center py-8">
                      No transactions yet
                    </p>
                  ) : (
                    transactions.slice(0, 5).map((transaction) => (
                      <div key={transaction.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex items-center gap-3">
                          {getStatusIcon(transaction.status)}
                          <div>
                            <p className="text-sm font-medium">
                              {transaction.type === 'deposit' ? 'Deposit' : 'Withdrawal'}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {transaction.cashAppTag}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-medium">
                            {transaction.type === 'deposit' ? '+' : '-'}${transaction.amount}
                          </p>
                          <Badge className={`text-xs ${getStatusColor(transaction.status)}`}>
                            {transaction.status}
                          </Badge>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <Card className="bg-white/95 backdrop-blur mt-4">
              <CardHeader>
                <CardTitle>Payment Stats</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Total Deposits</span>
                    <span className="text-sm font-medium">
                      ${transactions.filter(t => t.type === 'deposit' && t.status === 'completed').reduce((sum, t) => sum + t.amount, 0)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Total Withdrawals</span>
                    <span className="text-sm font-medium">
                      ${transactions.filter(t => t.type === 'withdrawal' && t.status === 'completed').reduce((sum, t) => sum + t.amount, 0)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Pending</span>
                    <span className="text-sm font-medium">
                      {transactions.filter(t => t.status === 'pending').length}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}