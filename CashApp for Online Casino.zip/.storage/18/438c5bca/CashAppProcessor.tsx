import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { QrCode, Copy, CheckCircle2, AlertCircle, DollarSign } from 'lucide-react';
import { toast } from 'sonner';

interface PaymentRequest {
  id: string;
  amount: number;
  playerTag: string;
  status: 'pending' | 'completed' | 'expired';
  timestamp: Date;
  paymentLink: string;
  cashtag: string;
}

interface CashAppProcessorProps {
  houseCashTag: string;
  onPaymentReceived: (amount: number, playerTag: string) => void;
}

export default function CashAppProcessor({ houseCashTag, onPaymentReceived }: CashAppProcessorProps) {
  const [amount, setAmount] = useState('');
  const [playerTag, setPlayerTag] = useState('');
  const [activeRequests, setActiveRequests] = useState<PaymentRequest[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);

  const generatePaymentRequest = async () => {
    if (!amount || !playerTag) {
      toast.error('Please enter amount and player CashApp tag');
      return;
    }

    if (parseFloat(amount) < 5) {
      toast.error('Minimum deposit is $5');
      return;
    }

    setIsGenerating(true);

    // Generate payment request
    const request: PaymentRequest = {
      id: `req_${Date.now()}`,
      amount: parseFloat(amount),
      playerTag: playerTag.startsWith('$') ? playerTag : `$${playerTag}`,
      status: 'pending',
      timestamp: new Date(),
      paymentLink: `https://cash.app/${houseCashTag}/${parseFloat(amount)}`,
      cashtag: houseCashTag
    };

    setActiveRequests(prev => [request, ...prev]);
    setIsGenerating(false);
    setAmount('');
    setPlayerTag('');

    toast.success('Payment request generated! Share the link with the player.');

    // Simulate payment completion after 30 seconds (in real implementation, this would be webhook-based)
    setTimeout(() => {
      setActiveRequests(prev => 
        prev.map(req => 
          req.id === request.id 
            ? { ...req, status: 'completed' as const }
            : req
        )
      );
      onPaymentReceived(request.amount, request.playerTag);
      toast.success(`Payment of $${request.amount} received from ${request.playerTag}!`);
    }, 30000);

    // Auto-expire after 10 minutes
    setTimeout(() => {
      setActiveRequests(prev => 
        prev.map(req => 
          req.id === request.id && req.status === 'pending'
            ? { ...req, status: 'expired' as const }
            : req
        )
      );
    }, 600000);
  };

  const copyPaymentLink = (link: string) => {
    navigator.clipboard.writeText(link);
    toast.success('Payment link copied to clipboard!');
  };

  const markAsReceived = (requestId: string) => {
    const request = activeRequests.find(req => req.id === requestId);
    if (request) {
      setActiveRequests(prev => 
        prev.map(req => 
          req.id === requestId 
            ? { ...req, status: 'completed' as const }
            : req
        )
      );
      onPaymentReceived(request.amount, request.playerTag);
      toast.success(`Payment of $${request.amount} confirmed!`);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle2 className="h-4 w-4 text-green-500" />;
      case 'expired':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
      default:
        return <AlertCircle className="h-4 w-4 text-yellow-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'expired':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-yellow-100 text-yellow-800';
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-white/95 backdrop-blur">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="h-5 w-5 text-green-500" />
            PayFate CashApp Processor
          </CardTitle>
          <CardDescription>
            Generate payment requests for players - no bank account needed
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert className="border-blue-200 bg-blue-50">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription className="text-blue-800">
              <strong>House CashTag:</strong> ${houseCashTag} - Players send money directly to this tag
            </AlertDescription>
          </Alert>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="player-tag">Player CashApp Tag</Label>
              <Input
                id="player-tag"
                placeholder="$PlayerUsername"
                value={playerTag}
                onChange={(e) => setPlayerTag(e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="amount">Deposit Amount</Label>
              <div className="relative">
                <DollarSign className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="amount"
                  type="number"
                  placeholder="0.00"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="pl-10"
                  min="5"
                />
              </div>
            </div>
          </div>

          <Button 
            onClick={generatePaymentRequest} 
            disabled={isGenerating}
            className="w-full bg-green-600 hover:bg-green-700"
          >
            {isGenerating ? 'Generating...' : 'Generate Payment Request'}
          </Button>
        </CardContent>
      </Card>

      {/* Active Payment Requests */}
      {activeRequests.length > 0 && (
        <Card className="bg-white/95 backdrop-blur">
          <CardHeader>
            <CardTitle>Active Payment Requests</CardTitle>
            <CardDescription>Pending and recent payment requests</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {activeRequests.slice(0, 10).map((request) => (
                <div key={request.id} className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      {getStatusIcon(request.status)}
                      <div>
                        <p className="font-medium">{request.playerTag}</p>
                        <p className="text-sm text-muted-foreground">
                          ${request.amount} • {request.timestamp.toLocaleString()}
                        </p>
                      </div>
                    </div>
                    <Badge className={getStatusColor(request.status)}>
                      {request.status}
                    </Badge>
                  </div>

                  {request.status === 'pending' && (
                    <div className="space-y-3">
                      <div className="flex items-center gap-2 p-2 bg-gray-50 rounded text-sm font-mono">
                        <span className="flex-1">{request.paymentLink}</span>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => copyPaymentLink(request.paymentLink)}
                        >
                          <Copy className="h-3 w-3" />
                        </Button>
                      </div>
                      
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          onClick={() => markAsReceived(request.id)}
                          className="bg-green-600 hover:bg-green-700"
                        >
                          Mark as Received
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => copyPaymentLink(`Hey ${request.playerTag}! Please send $${request.amount} to ${houseCashTag} for your PayFate deposit. Link: ${request.paymentLink}`)}
                        >
                          Copy Message
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}