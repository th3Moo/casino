import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  CreditCard, 
  Shield, 
  Zap, 
  Users, 
  DollarSign, 
  Clock,
  CheckCircle,
  ArrowRight,
  Star
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function Index() {
  const navigate = useNavigate();

  const features = [
    {
      icon: <Zap className="h-6 w-6 text-yellow-500" />,
      title: "Instant Payments",
      description: "Lightning-fast deposits and withdrawals through CashApp"
    },
    {
      icon: <Shield className="h-6 w-6 text-green-500" />,
      title: "Bank-Level Security",
      description: "End-to-end encryption and secure payment processing"
    },
    {
      icon: <DollarSign className="h-6 w-6 text-blue-500" />,
      title: "No Hidden Fees",
      description: "Transparent pricing with zero processing fees"
    },
    {
      icon: <Clock className="h-6 w-6 text-purple-500" />,
      title: "24/7 Support",
      description: "Round-the-clock customer support for all transactions"
    }
  ];

  const stats = [
    { label: "Active Users", value: "10,000+", icon: <Users className="h-5 w-5" /> },
    { label: "Total Processed", value: "$2.5M+", icon: <DollarSign className="h-5 w-5" /> },
    { label: "Success Rate", value: "99.9%", icon: <CheckCircle className="h-5 w-5" /> },
    { label: "Avg Processing", value: "< 30s", icon: <Clock className="h-5 w-5" /> }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Header */}
      <nav className="p-6 flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg"></div>
          <span className="text-2xl font-bold text-white">BitBetWin</span>
        </div>
        <div className="flex gap-4">
          <Button 
            variant="ghost" 
            onClick={() => navigate('/transactions')}
            className="text-white hover:bg-white/10"
          >
            Transaction History
          </Button>
          <Button 
            variant="ghost" 
            onClick={() => navigate('/admin')}
            className="text-white hover:bg-white/10"
          >
            Admin Dashboard
          </Button>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="max-w-7xl mx-auto px-6 py-20">
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-purple-100 text-purple-800 hover:bg-purple-100">
            🚀 Now Live: CashApp Integration
          </Badge>
          <h1 className="text-6xl font-bold text-white mb-6">
            Secure CashApp
            <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              {' '}Payment Gateway
            </span>
          </h1>
          <p className="text-xl text-slate-300 mb-8 max-w-3xl mx-auto">
            The most trusted payment processor for online gaming. Instant deposits and withdrawals 
            with enterprise-grade security and 99.9% uptime guarantee.
          </p>
          <div className="flex gap-4 justify-center">
            <Button 
              size="lg" 
              onClick={() => navigate('/payfate')}
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-lg px-8 py-3"
            >
              Enter PayFate Gameroom
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              onClick={() => navigate('/payment')}
              className="border-white/20 text-white hover:bg-white/10 text-lg px-8 py-3"
            >
              Payment Gateway
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-20">
          {stats.map((stat, index) => (
            <Card key={index} className="bg-white/10 border-white/20 backdrop-blur">
              <CardContent className="p-6 text-center">
                <div className="flex justify-center mb-2 text-white">
                  {stat.icon}
                </div>
                <div className="text-2xl font-bold text-white mb-1">{stat.value}</div>
                <div className="text-sm text-slate-300">{stat.label}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Features */}
        <div className="mb-20">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-white mb-4">Why Choose Our Gateway?</h2>
            <p className="text-xl text-slate-300">Built for the modern gaming industry</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <Card key={index} className="bg-white/95 backdrop-blur hover:shadow-xl transition-shadow">
                <CardHeader>
                  <div className="mb-2">{feature.icon}</div>
                  <CardTitle className="text-lg">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>{feature.description}</CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <Card className="bg-gradient-to-r from-purple-600 to-pink-600 border-0 text-white">
          <CardContent className="p-12 text-center">
            <div className="flex justify-center mb-6">
              <CreditCard className="h-16 w-16" />
            </div>
            <h3 className="text-3xl font-bold mb-4">Ready to Get Started?</h3>
            <p className="text-xl mb-8 opacity-90">
              Join thousands of satisfied customers processing millions in payments securely.
            </p>
            <div className="flex gap-4 justify-center">
              <Button 
                size="lg" 
                onClick={() => navigate('/payfate')}
                className="bg-white text-purple-600 hover:bg-gray-100 text-lg px-8 py-3"
              >
                Enter PayFate
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="border-white text-white hover:bg-white/10 text-lg px-8 py-3"
              >
                Contact Sales
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Testimonials */}
        <div className="mt-20 text-center">
          <h3 className="text-3xl font-bold text-white mb-12">Trusted by Industry Leaders</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                name: "Casino Royal",
                rating: 5,
                comment: "Best payment processor we've ever used. Lightning fast and reliable."
              },
              {
                name: "Lucky Slots",
                rating: 5,
                comment: "Customer support is amazing. Zero downtime in 6 months of usage."
              },
              {
                name: "Poker Pro",
                rating: 5,
                comment: "The security features give us and our players complete peace of mind."
              }
            ].map((testimonial, index) => (
              <Card key={index} className="bg-white/95 backdrop-blur">
                <CardContent className="p-6">
                  <div className="flex justify-center mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 text-yellow-500 fill-current" />
                    ))}
                  </div>
                  <p className="text-muted-foreground mb-4">"{testimonial.comment}"</p>
                  <p className="font-semibold">{testimonial.name}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t border-white/10 mt-20 py-12">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <div className="w-6 h-6 bg-gradient-to-r from-purple-500 to-pink-500 rounded"></div>
            <span className="text-xl font-bold text-white">BitBetWin Payment Gateway</span>
          </div>
          <p className="text-slate-400 mb-4">
            Secure, fast, and reliable payment processing for the gaming industry.
          </p>
          <div className="flex justify-center gap-8 text-sm text-slate-400">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-white transition-colors">API Documentation</a>
            <a href="#" className="hover:text-white transition-colors">Support</a>
          </div>
          <div className="mt-8 pt-8 border-t border-white/10">
            <p className="text-slate-500 text-sm">
              © 2024 BitBetWin Payment Gateway. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}